import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { fullScan } from '@/lib/scanner/scanner';
import { scanDNS, detectTechnology, getSecurityGrade } from '@/lib/scanner/comprehensiveScanner';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { createScanRow } from '@/lib/runScan';
import { enqueueWebScan, isAsyncScanEnabled } from '@/queues/scan.queue';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
    try {
        const session = await getServerSession(authOptions);

        const body = await req.json().catch(() => ({}));
        const targetUrl = body?.url || body?.targetUrl;
        const scanType = body?.scanType || 'full';
        const targetId = body?.targetId || null;

        if (!targetUrl) {
            return NextResponse.json({ error: 'URL is required' }, { status: 400 });
        }

        let parsedUrl: URL;
        try {
            parsedUrl = new URL(targetUrl);
        } catch {
            return NextResponse.json({ error: 'Invalid URL format' }, { status: 400 });
        }

        const domain = parsedUrl.hostname;
        const startTime = Date.now();

        // Fluxo assíncrono (BullMQ + Redis): enfileira e retorna imediatamente.
        // Padrão de produção: SCAN_ASYNC=false (síncrono, sem Redis obrigatório).
        if (isAsyncScanEnabled()) {
            const targetIdNum = targetId ? Number(targetId) : null;
            const userIdNum = session?.user?.id ? Number(session.user.id) : null;
            const scanId = await createScanRow(targetUrl, {
                userId: userIdNum,
                targetId: targetIdNum,
                scanType,
            });
            await enqueueWebScan({
                scanId,
                targetUrl,
                domain,
                userId: userIdNum,
                targetId: targetIdNum,
            });
            return NextResponse.json({
                scanId,
                targetUrl,
                domain,
                status: 'queued',
                async: true,
            });
        }

        const insertResult = await query(
            `INSERT INTO scans (user_id, target_id, target_url, domain, scan_type, status, started_at)
             VALUES ($1, $2, $3, $4, $5, $6, now()) RETURNING id`,
            [session?.user?.id ?? null, targetId, targetUrl, domain, scanType, 'running']
        );

        const scanId = insertResult[0].id;

        try {
            const [scanResult, dnsAnalysis, techDetection] = await Promise.all([
                fullScan(targetUrl),
                scanDNS(domain),
                detectTechnology(targetUrl),
            ]);

            const techScore = Math.max(20, 100 - techDetection.length * 15);

            // Se TLS está indisponivel (rede/proxy/MITM), não penaliza o score: redistribui
            // o peso do TLS entre headers e DNS (falha de rede != problema de segurança).
            const tlsScore = scanResult.tls?.issues?.includes('TLS scan failed')
                ? null
                : (scanResult.tls?.score ?? 60);

            const weights = tlsScore === null
                ? { scan: 0.7, dns: 0.3 }
                : { scan: 0.55, dns: 0.2, tls: 0.15, tech: 0.1 };

            const score = Math.max(
                0,
                Math.min(
                    100,
                    Math.round(
                        scanResult.score * weights.scan +
                            dnsAnalysis.score * weights.dns +
                            (tlsScore ?? 0) * (weights.tls ?? 0) +
                            techScore * (weights.tech ?? 0)
                    )
                )
            );

            const grade = getSecurityGrade(score);
            const duration = Date.now() - startTime;

            await query(
                `UPDATE scans SET
                    status = $1,
                    score = $2,
                    grade = $3,
                    headers = $4,
                    cookies = $5,
                    tls = $6,
                    dns = $7,
                    technology = $8,
                    vulnerabilities = $9,
                    info_disclosure = $10,
                    subdomains_found = $11,
                    duration_ms = $12,
                    completed_at = now()
                WHERE id = $13`,
                [
                    'completed',
                    score,
                    grade,
                    JSON.stringify(scanResult.headers),
                    JSON.stringify(scanResult.cookies),
                    JSON.stringify(scanResult.tls),
                    JSON.stringify(dnsAnalysis),
                    JSON.stringify(techDetection),
                    JSON.stringify(scanResult.vulnerabilities),
                    JSON.stringify(scanResult.infoDisclosure),
                    '{' + dnsAnalysis.subdomains.map((s) => s.subdomain).join(',') + '}',
                    duration,
                    scanId,
                ]
            );

            if (session?.user?.id) {
                await query(
                    'INSERT INTO usage_logs (user_id, action, metadata) VALUES ($1, $2, $3)',
                    [session.user.id, 'scan', JSON.stringify({ targetUrl, score, duration })]
                );
            }

            return NextResponse.json({
                scanId,
                targetUrl,
                domain,
                score,
                grade,
                duration_ms: duration,
                status: 'completed',
                headers: scanResult.headers,
                cookies: scanResult.cookies,
                tls: scanResult.tls,
                dns: dnsAnalysis,
                technology: techDetection,
                vulnerabilities: scanResult.vulnerabilities,
                infoDisclosure: scanResult.infoDisclosure,
            });
        } catch (scanErr: any) {
            await query(
                'UPDATE scans SET status = $1, error = $2, completed_at = now() WHERE id = $3',
                ['failed', scanErr.message, scanId]
            );
            return NextResponse.json(
                { error: 'Scan failed', details: scanErr.message },
                { status: 500 }
            );
        }
    } catch (err: any) {
        return NextResponse.json({ error: err.message }, { status: 500 });
    }
}

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const targetId = searchParams.get('targetId');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');
    const status = searchParams.get('status');

    const conditions: string[] = [];
    const params: any[] = [];
    let paramIdx = 1;

    if (targetId) {
        conditions.push(`s.target_id = $${paramIdx++}`);
        params.push(targetId);
    }
    if (status) {
        conditions.push(`s.status = $${paramIdx++}`);
        params.push(status);
    }

    const baseSql = `SELECT s.id, s.target_url as "targetUrl", s.domain, s.scan_type as "scanType",
        s.status, s.score, s.grade, s.duration_ms as "durationMs",
        s.error, s.created_at as "createdAt", s.completed_at as "completedAt",
        s.user_id as "userId"
        FROM scans s`;
    const where = conditions.length > 0 ? ' WHERE ' + conditions.join(' AND ') : '';

    const rows = await query(
        `${baseSql}${where} ORDER BY s.created_at DESC LIMIT $${paramIdx} OFFSET $${paramIdx + 1}`,
        [...params, limit, offset]
    );

    const countResult = await query(
        `SELECT COUNT(*) as count FROM scans s${where}`,
        params
    );

    return NextResponse.json({
        scans: rows,
        total: parseInt(countResult[0].count),
        limit,
        offset,
    });
}